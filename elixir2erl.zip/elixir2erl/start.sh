erl -pa elixir_lib -s elixir2erl | tee $0.log
ls ./*/*.erld